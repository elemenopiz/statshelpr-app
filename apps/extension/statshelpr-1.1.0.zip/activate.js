"use strict";
(() => {
  // src/install-id.ts
  var STORAGE_KEY_INSTALL_ID = "installId";
  async function getInstallId() {
    const r = await chrome.storage.sync.get(STORAGE_KEY_INSTALL_ID);
    const existing = r[STORAGE_KEY_INSTALL_ID];
    if (existing) return existing;
    const id = crypto.randomUUID();
    await chrome.storage.sync.set({ [STORAGE_KEY_INSTALL_ID]: id });
    return id;
  }

  // src/activate.ts
  var DEFAULT_API_URL = "https://api.statshelpr.com";
  function isActivateLicenseMessage(data) {
    if (typeof data !== "object" || data === null) return false;
    const msg = data;
    return msg["source"] === "statshelpr-web" && msg["type"] === "activate-license" && typeof msg["licenseKey"] === "string" && msg["licenseKey"].length > 0;
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (!isActivateLicenseMessage(event.data)) return;
    void handleActivation(event.data.licenseKey);
  });
  async function handleActivation(licenseKey) {
    await chrome.storage.sync.set({ licenseKey });
    const cfg = await chrome.storage.sync.get("apiUrl");
    const apiBase = (cfg["apiUrl"] ?? DEFAULT_API_URL).replace(/\/$/, "");
    const installId = await getInstallId();
    let data;
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 6e3);
      const res = await fetch(`${apiBase}/api/activate-license`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ licenseKey, installId }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      data = await res.json();
    } catch {
      return;
    }
    if (data.ok && data.activated) {
      await chrome.storage.local.set({ activationBlocked: false });
      window.postMessage(
        { source: "statshelpr-ext", type: "license-activated" },
        window.location.origin
      );
      return;
    }
    if (data.atLimit) {
      await chrome.storage.local.set({ activationBlocked: true });
      window.postMessage(
        { source: "statshelpr-ext", type: "activation-blocked", reason: "device-limit" },
        window.location.origin
      );
    }
  }
})();
