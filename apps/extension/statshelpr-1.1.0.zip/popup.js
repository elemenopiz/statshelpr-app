"use strict";
(() => {
  // src/r-packages.ts
  var RPKG_STORAGE_KEY = "statshelpr.rPackages";
  var DEFAULT_R_PACKAGES = [
    "tidyverse",
    "mosaic",
    "moderndive"
  ];
  var INSTALLED_CATALOG = [
    // ships in the rocker/tidyverse base image
    "tidyverse",
    "ggplot2",
    "broom",
    // installed on top by r-runner/Dockerfile
    "mosaic",
    "moderndive",
    "infer"
  ];
  var MAX_R_PACKAGES = 40;
  function isValidPackageName(name) {
    return /^[A-Za-z][A-Za-z0-9.]*$/.test(name) && name.length <= 64;
  }
  function isInstalled(name) {
    return INSTALLED_CATALOG.includes(name);
  }
  async function loadRPackages() {
    try {
      const r = await chrome.storage.sync.get(RPKG_STORAGE_KEY);
      const stored = r[RPKG_STORAGE_KEY];
      if (Array.isArray(stored)) {
        return { list: stored.filter(isValidPackageName).slice(0, MAX_R_PACKAGES), customized: true };
      }
      return { list: [...DEFAULT_R_PACKAGES], customized: false };
    } catch {
      return { list: [...DEFAULT_R_PACKAGES], customized: false };
    }
  }

  // src/install-id.ts
  var STORAGE_KEY_INSTALL_ID = "installId";
  async function getInstallId() {
    const r = await chrome.storage.sync.get(STORAGE_KEY_INSTALL_ID);
    const existing = r[STORAGE_KEY_INSTALL_ID];
    if (existing) return existing;
    const id = crypto.randomUUID();
    await chrome.storage.sync.set({ [STORAGE_KEY_INSTALL_ID]: id });
    return id;
  }

  // src/claim-license.ts
  var DEFAULT_API_URL = "https://api.statshelpr.com";
  var CLAIM_ALARM = "statshelpr-claim-license";
  var STORAGE_KEY_CLAIM_STARTED = "claimStartedAt";
  var CLAIM_WINDOW_MS = 45 * 6e4;
  var CLAIM_PERIOD_MIN = 0.5;
  async function startClaiming() {
    await chrome.storage.local.set({ [STORAGE_KEY_CLAIM_STARTED]: Date.now() });
    chrome.alarms.create(CLAIM_ALARM, {
      delayInMinutes: CLAIM_PERIOD_MIN,
      periodInMinutes: CLAIM_PERIOD_MIN
    });
  }
  async function stopClaiming() {
    await chrome.storage.local.remove(STORAGE_KEY_CLAIM_STARTED);
    await chrome.alarms.clear(CLAIM_ALARM);
  }
  async function tryClaimLicense() {
    const r = await chrome.storage.local.get(STORAGE_KEY_CLAIM_STARTED);
    const startedAt = r[STORAGE_KEY_CLAIM_STARTED];
    if (!startedAt) return "none";
    if (Date.now() - startedAt > CLAIM_WINDOW_MS) {
      await stopClaiming();
      return "none";
    }
    const cfg = await chrome.storage.sync.get("apiUrl");
    const apiBase = (cfg["apiUrl"] ?? DEFAULT_API_URL).replace(/\/$/, "");
    const installId = await getInstallId();
    let data;
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 6e3);
      const res = await fetch(`${apiBase}/api/claim-license`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ installId }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      data = await res.json();
    } catch {
      return "pending";
    }
    if (!data.ok || !data.licenseKey) return "pending";
    await chrome.storage.sync.set({ licenseKey: data.licenseKey });
    await chrome.storage.local.set({ activationBlocked: false });
    await stopClaiming();
    return "claimed";
  }

  // src/popup.ts
  var DEFAULT_OPACITY = 1;
  var API_URL = "https://api.statshelpr.com";
  var STORAGE_KEY_THEME = "statshelpr.theme";
  var STORAGE_KEY_FILES = "statshelpr.files";
  var FILE_TTL_MS = 7 * 24 * 60 * 60 * 1e3;
  var MAX_FILE_BYTES = 5 * 1024 * 1024;
  var MAX_TOTAL_BYTES = 8 * 1024 * 1024;
  var STORAGE_KEY_SOLVE_STATS = "statshelpr.solveStats";
  var FREE_DAILY_LIMIT = 5;
  var STORAGE_KEY_PLAN_CACHE = "statshelpr.planCache";
  var PLAN_CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1e3;
  var opacityInput = document.getElementById("buttonOpacity");
  var opacityValueEl = document.getElementById("opacityValue");
  var opacityLockEl = document.getElementById("opacity-lock");
  var statusEl = document.getElementById("status");
  var statusDot = document.getElementById("status-dot");
  var metaEl = document.getElementById("meta");
  var dropzone = document.getElementById("dropzone");
  var fileInput = document.getElementById("file-input");
  var filesList = document.getElementById("files-list");
  var filesEmpty = document.getElementById("files-empty");
  var planCardEl = document.getElementById("plan-card");
  var planSolvesEl = document.getElementById("plan-solves");
  var solvesMeterEl = document.getElementById("solves-meter");
  var upgradeCtaEl = document.getElementById("upgrade-cta");
  var planNoteEl = document.getElementById("plan-note");
  var versionEl = document.getElementById("ext-version");
  var themeToggleEl = document.getElementById("theme-toggle");
  var deviceLimitNoteEl = document.getElementById("device-limit-note");
  var resetDeviceBtn = document.getElementById("reset-device-btn");
  var resetStatusEl = document.getElementById("reset-status");
  var dataFiles = [];
  var currentPlan = "free";
  function systemTheme() {
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  var SVG_NS = "http://www.w3.org/2000/svg";
  function svgEl(tag, attrs) {
    const node = document.createElementNS(SVG_NS, tag);
    for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
    return node;
  }
  function buildMoonIcon() {
    const svg = svgEl("svg", { width: "13", height: "13", viewBox: "0 0 24 24", "aria-hidden": "true" });
    const mask = svgEl("mask", { id: "sh-moon-mask" });
    mask.appendChild(svgEl("rect", { width: "24", height: "24", fill: "#fff" }));
    mask.appendChild(svgEl("circle", { cx: "15", cy: "9", r: "7", fill: "#000" }));
    svg.appendChild(mask);
    svg.appendChild(
      svgEl("circle", { cx: "12", cy: "12", r: "9", fill: "currentColor", mask: "url(#sh-moon-mask)" })
    );
    return svg;
  }
  function buildSunIcon() {
    const svg = svgEl("svg", {
      width: "13",
      height: "13",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      "stroke-width": "2",
      "stroke-linecap": "round",
      "aria-hidden": "true"
    });
    svg.appendChild(svgEl("circle", { cx: "12", cy: "12", r: "5", fill: "currentColor", stroke: "none" }));
    const rays = [
      ["12", "2", "12", "5"],
      ["12", "19", "12", "22"],
      ["2", "12", "5", "12"],
      ["19", "12", "22", "12"],
      ["4.9", "4.9", "7", "7"],
      ["17", "17", "19.1", "19.1"],
      ["4.9", "19.1", "7", "17"],
      ["17", "7", "19.1", "4.9"]
    ];
    for (const [x1, y1, x2, y2] of rays) {
      svg.appendChild(svgEl("line", { x1, y1, x2, y2 }));
    }
    return svg;
  }
  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    if (themeToggleEl) {
      const next = theme === "dark" ? "light" : "dark";
      themeToggleEl.replaceChildren(theme === "dark" ? buildMoonIcon() : buildSunIcon());
      themeToggleEl.setAttribute("aria-label", `Switch to ${next} theme`);
      themeToggleEl.title = "Switch theme";
    }
  }
  (async () => {
    let theme = systemTheme();
    try {
      const r = await chrome.storage.local.get(STORAGE_KEY_THEME);
      const stored = r[STORAGE_KEY_THEME];
      if (stored === "light" || stored === "dark") theme = stored;
    } catch {
    }
    applyTheme(theme);
  })();
  themeToggleEl?.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light";
    const next = current === "dark" ? "light" : "dark";
    applyTheme(next);
    try {
      void chrome.storage.local.set({ [STORAGE_KEY_THEME]: next });
    } catch {
    }
  });
  function dialToPercent(dial) {
    return Math.round(Math.min(1, Math.max(0, dial)) * 100);
  }
  chrome.storage.sync.get(["apiUrl", "licenseKey", "buttonOpacity"], (cfg) => {
    const dial = typeof cfg.buttonOpacity === "number" ? cfg.buttonOpacity : DEFAULT_OPACITY;
    const pct = dialToPercent(dial);
    if (opacityInput) opacityInput.value = String(pct);
    if (opacityValueEl) opacityValueEl.textContent = `${pct}%`;
    void pingHealth(API_URL);
    void refreshPlan(API_URL, cfg.licenseKey ?? "");
    void tryClaimLicense();
  });
  void getInstallId().then((id) => {
    const param = "checkout[custom][install_id]=" + encodeURIComponent(id);
    [upgradeCtaEl, opacityLockEl].forEach((a) => {
      if (!a) return;
      const href = a.getAttribute("href");
      if (!href) return;
      a.href = href + (href.includes("?") ? "&" : "?") + param;
    });
  });
  function previewOpacityOnActiveTab(dial) {
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const id = tabs[0]?.id;
        if (id == null) return;
        chrome.tabs.sendMessage(id, { type: "sh-preview-opacity", value: dial }, () => {
          void chrome.runtime.lastError;
        });
      });
    } catch {
    }
  }
  opacityInput?.addEventListener("input", () => {
    const pct = Number(opacityInput.value);
    if (!Number.isFinite(pct)) return;
    if (opacityValueEl) opacityValueEl.textContent = `${Math.round(pct)}%`;
    previewOpacityOnActiveTab(pct / 100);
  });
  opacityInput?.addEventListener("change", () => {
    const pct = Number(opacityInput.value);
    if (currentPlan !== "paid") {
      if (opacityInput) opacityInput.value = "100";
      if (opacityValueEl) opacityValueEl.textContent = "100%";
      previewOpacityOnActiveTab(1);
      flashOpacityLock();
      return;
    }
    void chrome.storage.sync.set({
      buttonOpacity: Number.isFinite(pct) ? Math.min(1, Math.max(0, pct / 100)) : DEFAULT_OPACITY
    });
  });
  var lockPulseTimer;
  function flashOpacityLock() {
    if (!opacityLockEl) return;
    opacityLockEl.classList.remove("pulse");
    void opacityLockEl.offsetWidth;
    opacityLockEl.classList.add("pulse");
    if (lockPulseTimer) clearTimeout(lockPulseTimer);
    lockPulseTimer = setTimeout(() => opacityLockEl?.classList.remove("pulse"), 1e3);
  }
  async function pingHealth(apiUrl) {
    setDot("checking\u2026", "");
    metaEl.style.display = "none";
    if (!apiUrl) return setDot("not set", "err");
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 4e3);
      const res = await fetch(`${apiUrl.replace(/\/$/, "")}/api/health`, {
        signal: ctrl.signal
      });
      clearTimeout(timer);
      if (!res.ok) return setDot(`API ${res.status}`, "err");
      const data = await res.json();
      const aiTutorReady = data.geminiConfigured ?? data.kimiConfigured ?? data.moonshotConfigured ?? false;
      if (!aiTutorReady) {
        setDot("api key missing", "warn");
      } else {
        setDot("ready", "ok");
      }
      renderMeta(data);
    } catch {
      setDot("offline", "err");
    }
  }
  function setDot(label, kind) {
    statusDot.textContent = label;
    statusDot.className = `dot${kind ? ` ${kind}` : ""}`;
  }
  function renderMeta(data) {
    while (metaEl.firstChild) metaEl.removeChild(metaEl.firstChild);
    const aiTutorReady = data.geminiConfigured ?? data.kimiConfigured ?? data.moonshotConfigured ?? false;
    const rows = [
      ["version", data.version ?? "\u2014", ""],
      ["ai tutor", aiTutorReady ? "ready" : "not set", aiTutorReady ? "ok" : "warn"],
      ["license", data.lemonsqueezyConfigured ? "gated" : "open", data.lemonsqueezyConfigured ? "ok" : ""]
    ];
    for (const [k, v, kind] of rows) {
      const row = document.createElement("div");
      const b = document.createElement("b");
      b.textContent = k;
      row.appendChild(b);
      const val = document.createElement("span");
      val.className = `v${kind ? ` ${kind}` : ""}`;
      val.textContent = v;
      row.appendChild(val);
      metaEl.appendChild(row);
    }
    metaEl.style.display = "";
  }
  document.getElementById("open-tutorial")?.addEventListener("click", (e) => {
    e.preventDefault();
    void chrome.runtime.sendMessage({ type: "openWelcome" });
    window.close();
  });
  try {
    versionEl.textContent = `v${chrome.runtime.getManifest().version}`;
  } catch {
  }
  function openCheckout(anchor) {
    void (async () => {
      try {
        await startClaiming();
      } catch {
      }
      try {
        await chrome.tabs.create({ url: anchor.href });
      } catch {
        window.open(anchor.href, "_blank", "noopener");
      }
      window.close();
    })();
  }
  upgradeCtaEl.addEventListener("click", (e) => {
    e.preventDefault();
    openCheckout(upgradeCtaEl);
  });
  opacityLockEl?.addEventListener("click", (e) => {
    e.preventDefault();
    openCheckout(opacityLockEl);
  });
  function setPlan(plan) {
    planCardEl.dataset["plan"] = plan;
  }
  function setPlanNote(msg) {
    planNoteEl.textContent = msg;
    planNoteEl.style.display = msg ? "block" : "none";
  }
  function applyOpacityGate(plan) {
    currentPlan = plan;
    if (opacityInput) {
      opacityInput.disabled = false;
      if (plan === "free") {
        opacityInput.value = "100";
        if (opacityValueEl) opacityValueEl.textContent = "100%";
      }
    }
    if (opacityLockEl) {
      opacityLockEl.style.display = plan === "free" ? "flex" : "none";
    }
  }
  async function refreshPlan(apiUrl, licenseKey) {
    setPlanNote("");
    void renderSolvesLeft();
    if (!licenseKey) {
      setPlan("free");
      applyOpacityGate("free");
      await writePlanCache(false);
      return;
    }
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 4e3);
      const res = await fetch(`${apiUrl.replace(/\/$/, "")}/api/auth/validate-license`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ licenseKey }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      const data = await res.json();
      if (data.ok) {
        setPlan("paid");
        applyOpacityGate("paid");
        await writePlanCache(true);
      } else {
        setPlan("free");
        applyOpacityGate("free");
        const reason = data.reason ?? "license invalid";
        setPlanNote(`License issue: ${reason} \u2014 you're on the free plan for now.`);
        await writePlanCache(false);
      }
    } catch {
      const cached = await readPlanCache();
      if (cached?.paid) {
        setPlan("paid");
        applyOpacityGate("paid");
      } else {
        setPlan("free");
        applyOpacityGate("free");
      }
    }
  }
  async function readPlanCache() {
    try {
      const r = await chrome.storage.local.get(STORAGE_KEY_PLAN_CACHE);
      const c = r[STORAGE_KEY_PLAN_CACHE];
      if (!c || Date.now() - c.at > PLAN_CACHE_TTL_MS) return null;
      return c;
    } catch {
      return null;
    }
  }
  async function writePlanCache(paid) {
    try {
      await chrome.storage.local.set({
        [STORAGE_KEY_PLAN_CACHE]: { paid, at: Date.now() }
      });
    } catch {
    }
  }
  async function renderSolvesLeft() {
    let remaining = FREE_DAILY_LIMIT;
    let resetAt = 0;
    try {
      const r = await chrome.storage.local.get(STORAGE_KEY_SOLVE_STATS);
      const stats = r[STORAGE_KEY_SOLVE_STATS];
      if (stats && stats.resetAt > Date.now()) {
        remaining = Math.max(0, FREE_DAILY_LIMIT - stats.count);
        resetAt = stats.resetAt;
      }
    } catch {
    }
    while (planSolvesEl.firstChild) planSolvesEl.removeChild(planSolvesEl.firstChild);
    const b = document.createElement("b");
    b.textContent = String(remaining);
    planSolvesEl.appendChild(b);
    if (remaining === 0 && resetAt) {
      const hrs = Math.max(1, Math.ceil((resetAt - Date.now()) / 36e5));
      planSolvesEl.appendChild(
        document.createTextNode(` of ${FREE_DAILY_LIMIT} left \u2014 resets in ~${hrs}h`)
      );
    } else {
      planSolvesEl.appendChild(
        document.createTextNode(` of ${FREE_DAILY_LIMIT} solves left today`)
      );
    }
    const segs = solvesMeterEl.querySelectorAll("span");
    segs.forEach((seg, i) => seg.classList.toggle("on", i < remaining));
    const urgent = remaining <= 1;
    planSolvesEl.classList.toggle("urgent", urgent);
    upgradeCtaEl.classList.toggle("urgent", urgent);
  }
  var STORAGE_KEY_ACTIVATION_BLOCKED = "activationBlocked";
  void refreshDeviceLimitState();
  async function refreshDeviceLimitState() {
    try {
      const r = await chrome.storage.local.get(STORAGE_KEY_ACTIVATION_BLOCKED);
      setDeviceLimitBlocked(Boolean(r[STORAGE_KEY_ACTIVATION_BLOCKED]));
    } catch {
    }
  }
  function setDeviceLimitBlocked(blocked) {
    deviceLimitNoteEl.style.display = blocked ? "block" : "none";
    if (!blocked) setResetStatus("", "");
  }
  function setResetStatus(msg, kind) {
    resetStatusEl.textContent = msg;
    resetStatusEl.className = `status${kind ? ` ${kind}` : ""}`;
    resetStatusEl.style.display = msg ? "block" : "none";
  }
  resetDeviceBtn.addEventListener("click", () => {
    void requestReset();
  });
  async function requestReset() {
    resetDeviceBtn.disabled = true;
    setResetStatus("Requesting reset\u2026", "");
    try {
      const cfg = await chrome.storage.sync.get("licenseKey");
      const licenseKey = cfg["licenseKey"] ?? "";
      if (!licenseKey) {
        setResetStatus("No license key found \u2014 activate first.", "err");
        return;
      }
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 6e3);
      const res = await fetch(`${API_URL.replace(/\/$/, "")}/api/reset/request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ licenseKey }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      if (!res.ok) {
        setResetStatus("Couldn't request a reset \u2014 try again shortly.", "err");
        return;
      }
      const data = await res.json();
      if (data.ok && data.method === "portal" && data.url) {
        void chrome.tabs.create({ url: data.url });
        setResetStatus("Opened the reset page in a new tab.", "ok");
      } else if (data.ok && data.method === "email") {
        setResetStatus("Check your email for a reset link.", "ok");
      } else {
        setResetStatus("Couldn't request a reset \u2014 try again shortly.", "err");
      }
    } catch {
      setResetStatus("Network error \u2014 check your connection and try again.", "err");
    } finally {
      resetDeviceBtn.disabled = false;
    }
  }
  void loadFiles().then(() => renderFilesList());
  dropzone.addEventListener("click", () => fileInput.click());
  dropzone.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      fileInput.click();
    }
  });
  fileInput.addEventListener("change", async () => {
    if (fileInput.files) await ingestFiles([...fileInput.files]);
    fileInput.value = "";
  });
  dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropzone.classList.add("drag-over");
  });
  dropzone.addEventListener("dragleave", () => dropzone.classList.remove("drag-over"));
  dropzone.addEventListener("drop", async (e) => {
    e.preventDefault();
    dropzone.classList.remove("drag-over");
    if (e.dataTransfer?.files) await ingestFiles([...e.dataTransfer.files]);
  });
  async function ingestFiles(files) {
    let warnedSize = false;
    for (const f of files) {
      if (f.size > MAX_FILE_BYTES) {
        if (!warnedSize) {
          flashStatus(`${f.name} is too large (>5MB)`, "err");
          warnedSize = true;
        }
        continue;
      }
      const text = await f.text();
      dataFiles = dataFiles.filter((d) => d.filename !== f.name);
      dataFiles.push({
        filename: f.name,
        content: text,
        size: text.length,
        addedAt: Date.now()
      });
    }
    let total = dataFiles.reduce((sum, d) => sum + d.size, 0);
    while (total > MAX_TOTAL_BYTES && dataFiles.length > 0) {
      const oldest = dataFiles.reduce((a, b) => a.addedAt < b.addedAt ? a : b);
      dataFiles = dataFiles.filter((d) => d !== oldest);
      total -= oldest.size;
    }
    await saveFiles();
    renderFilesList();
  }
  function renderFilesList() {
    while (filesList.firstChild) filesList.removeChild(filesList.firstChild);
    if (dataFiles.length === 0) {
      filesEmpty.style.display = "";
      return;
    }
    filesEmpty.style.display = "none";
    for (const f of dataFiles) {
      const row = document.createElement("div");
      row.className = "row";
      const name = document.createElement("span");
      name.className = "name";
      name.textContent = f.filename;
      name.title = f.filename;
      const size = document.createElement("span");
      size.className = "size";
      size.textContent = `${(f.size / 1024).toFixed(1)} kb`;
      const rm = document.createElement("button");
      rm.className = "remove";
      rm.textContent = "\xD7";
      rm.title = "remove";
      rm.setAttribute("aria-label", `remove ${f.filename}`);
      rm.addEventListener("click", async () => {
        dataFiles = dataFiles.filter((d) => d.filename !== f.filename);
        await saveFiles();
        renderFilesList();
      });
      row.appendChild(name);
      row.appendChild(size);
      row.appendChild(rm);
      filesList.appendChild(row);
    }
  }
  async function loadFiles() {
    const r = await chrome.storage.local.get(STORAGE_KEY_FILES);
    const stored = r[STORAGE_KEY_FILES] ?? [];
    const now = Date.now();
    dataFiles = stored.filter((f) => now - f.addedAt < FILE_TTL_MS);
    if (dataFiles.length !== stored.length) await saveFiles();
  }
  async function saveFiles() {
    await chrome.storage.local.set({ [STORAGE_KEY_FILES]: dataFiles });
  }
  function flashStatus(msg, kind) {
    statusEl.textContent = msg;
    statusEl.className = `status ${kind}`;
    setTimeout(() => {
      statusEl.textContent = "";
      statusEl.className = "status";
    }, 2400);
  }
  var rpkgChipsEl = document.getElementById("rpkg-chips");
  var rpkgInput = document.getElementById("rpkg-input");
  var rpkgAddBtn = document.getElementById("rpkg-add");
  var rpkgEmptyEl = document.getElementById("rpkg-empty");
  var rPackages = [];
  void loadRPackages().then(({ list }) => {
    rPackages = list;
    renderRPackages();
  });
  rpkgAddBtn.addEventListener("click", () => void addRPackagesFromInput());
  rpkgInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      void addRPackagesFromInput();
    }
  });
  function renderRPackages() {
    while (rpkgChipsEl.firstChild) rpkgChipsEl.removeChild(rpkgChipsEl.firstChild);
    rpkgEmptyEl.style.display = rPackages.length === 0 ? "" : "none";
    for (const pkg of rPackages) {
      const installed = isInstalled(pkg);
      const chip = document.createElement("span");
      chip.className = installed ? "chip" : "chip unknown";
      if (!installed) chip.title = "Not pre-installed on the server yet \u2014 may not run.";
      const label = document.createElement("span");
      label.textContent = pkg;
      const rm = document.createElement("button");
      rm.className = "rm";
      rm.textContent = "\xD7";
      rm.title = `remove ${pkg}`;
      rm.setAttribute("aria-label", `remove ${pkg}`);
      rm.addEventListener("click", () => {
        rPackages = rPackages.filter((p) => p !== pkg);
        void saveRPackages();
        renderRPackages();
      });
      chip.appendChild(label);
      chip.appendChild(rm);
      rpkgChipsEl.appendChild(chip);
    }
  }
  async function addRPackagesFromInput() {
    const candidates = rpkgInput.value.split(/[,\s]+/).map((s) => s.trim()).filter((s) => s.length > 0);
    rpkgInput.value = "";
    if (candidates.length === 0) return;
    let changed = false;
    for (const pkg of candidates) {
      if (!isValidPackageName(pkg)) continue;
      if (rPackages.includes(pkg)) continue;
      if (rPackages.length >= MAX_R_PACKAGES) break;
      rPackages.push(pkg);
      changed = true;
    }
    if (changed) {
      await saveRPackages();
      renderRPackages();
    }
  }
  async function saveRPackages() {
    try {
      await chrome.storage.sync.set({ [RPKG_STORAGE_KEY]: rPackages });
    } catch {
    }
  }
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[STORAGE_KEY_SOLVE_STATS]) {
        void renderSolvesLeft();
      }
      if (area === "local" && changes[STORAGE_KEY_FILES]) {
        void loadFiles().then(() => renderFilesList());
      }
      if (area === "local" && changes[STORAGE_KEY_ACTIVATION_BLOCKED]) {
        setDeviceLimitBlocked(Boolean(changes[STORAGE_KEY_ACTIVATION_BLOCKED]?.newValue));
      }
      if (area === "sync" && changes["licenseKey"]) {
        const newKey = changes["licenseKey"].newValue ?? "";
        void refreshPlan(API_URL, newKey);
      }
    });
  } catch {
  }
})();
