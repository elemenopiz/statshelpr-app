"use strict";
(() => {
  // src/install-id.ts
  var STORAGE_KEY_INSTALL_ID = "installId";
  async function getInstallId() {
    const r = await chrome.storage.sync.get(STORAGE_KEY_INSTALL_ID);
    const existing = r[STORAGE_KEY_INSTALL_ID];
    if (existing) return existing;
    const id = crypto.randomUUID();
    await chrome.storage.sync.set({ [STORAGE_KEY_INSTALL_ID]: id });
    return id;
  }

  // ../../packages/solver-core/src/core/text.ts
  function normalizeText(text) {
    return text.replace(/\s+/g, " ").trim();
  }
  function dedupeDoubled(text) {
    const t = normalizeText(text);
    if (t.length < 24) return t;
    const norm = (s) => s.replace(/\\[a-zA-Z]+/g, "").replace(/[^a-z0-9]/gi, "").toLowerCase();
    const head = t.slice(0, 12);
    for (let from = 8; from < t.length; ) {
      const idx = t.indexOf(head, from);
      if (idx < 0) break;
      const a = t.slice(0, idx).trim();
      const b = t.slice(idx).trim();
      if (a && b && (a === b || norm(a).length > 4 && norm(a) === norm(b))) return a;
      from = idx + 1;
    }
    return t;
  }

  // src/canvas-dom.ts
  var SELECTORS_STEM = [
    ".question_text",
    ".user_content",
    "[data-testid='question-text']",
    "[data-testid='question-stem']",
    ".question-text-container",
    ".stem"
  ];
  var CHOICE_INPUT_SELECTOR = 'input[type="radio"], input[type="checkbox"]';
  var TEXT_INPUT_SELECTOR = [
    'input[type="text"]',
    'input[type="number"]',
    ".numerical_question_input",
    ".question_input"
  ].join(",");
  async function scrapeQuestion(question) {
    const stem = findStem(question);
    if (!stem) throw new Error("Could not find question text.");
    const stemText = cleanText(stem);
    if (!stemText) throw new Error("Question text is empty.");
    const images = await collectImages(question);
    const choices = collectAnswerChoices(question);
    const blanks = collectBlanks(question);
    return { text: stemText, choices, blanks, images };
  }
  function selectAnswerChoice(question, answer, selectedLabels = [], originalChoices) {
    const choices = collectAnswerChoices(question);
    if (choices.length === 0) return 0;
    if (choices.length === 1 && choices[0]?.kind === "text-fill") {
      return fillTextInput(choices[0].input, answer);
    }
    const selectedByBackend = selectedLabels.map((label) => choices.find((c2) => c2.label.toUpperCase() === label.toUpperCase())).filter((c2) => Boolean(c2)).filter((c2) => isLabelStillTrustworthy(c2, originalChoices));
    if (selectedByBackend.length > 0) {
      let count = 0;
      for (const c2 of selectedByBackend) count += applyChoice(c2);
      return count;
    }
    const checkboxes = choices.filter((c2) => c2.kind === "checkbox");
    if (checkboxes.length > 0) {
      const selected = findSelectedChoices(answer, choices, true);
      let count = 0;
      for (const c2 of selected) count += applyChoice(c2);
      return count;
    }
    const dropdown = choices.filter((c2) => c2.kind === "dropdown-option");
    if (dropdown.length > 0) {
      const c2 = pickByLetterOrText(answer, dropdown);
      return c2 ? applyChoice(c2) : 0;
    }
    const radios = choices.filter((c2) => c2.kind === "radio");
    if (radios.length === 0) return 0;
    const c = pickByLetterOrText(answer, radios);
    return c ? applyChoice(c) : 0;
  }
  function isLabelStillTrustworthy(current, originalChoices) {
    if (!originalChoices) return true;
    const original = originalChoices.find((o) => o.label.toUpperCase() === current.label.toUpperCase());
    if (!original) return true;
    return normalizeText2(original.text) === normalizeText2(current.text);
  }
  function pickByLetterOrText(answer, pool) {
    const letterMatch = answer.match(/^\s*(?:Answer\s*:?\s*)?\(?([A-Za-z]|\d{1,2})\)?[\s.,)]?/);
    if (letterMatch && letterMatch[1]) {
      const tok = letterMatch[1].toUpperCase();
      let idx = -1;
      if (/^[A-Z]$/.test(tok)) idx = tok.charCodeAt(0) - 65;
      else if (/^\d+$/.test(tok)) idx = parseInt(tok, 10) - 1;
      if (idx >= 0 && idx < pool.length) return pool[idx] ?? null;
    }
    const answerLower = answer.toLowerCase();
    let best = null;
    let bestScore = 0;
    for (const c of pool) {
      const choiceLower = c.text.toLowerCase().trim();
      if (!choiceLower) continue;
      let score = 0;
      if (answerLower.includes(choiceLower) && choiceLower.length >= 3) score = choiceLower.length;
      else if (choiceLower.includes(answerLower.slice(0, 40))) score = answerLower.length / 2;
      if (score > bestScore) {
        bestScore = score;
        best = c;
      }
    }
    return best;
  }
  function applyChoice(choice) {
    if (choice.kind === "dropdown-option") {
      return selectDropdownOption(choice);
    }
    if (choice.kind === "text-fill") {
      return 0;
    }
    return selectChoice(choice.input);
  }
  function selectDropdownOption(choice) {
    return setSelectValue(choice.input, choice.optionValue, choice.optionIndex);
  }
  function setSelectValue(sel, value, index) {
    if (sel.disabled) {
      sel.classList.add("statshelpr-suggested");
      return 1;
    }
    const proto = Object.getPrototypeOf(sel);
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter && value !== void 0) setter.call(sel, value);
    else if (index !== void 0) sel.selectedIndex = index;
    sel.dispatchEvent(new Event("input", { bubbles: true }));
    sel.dispatchEvent(new Event("change", { bubbles: true }));
    sel.classList.add("statshelpr-suggested");
    return 1;
  }
  function fillTextInput(input, answer) {
    const m = answer.match(/(?:Answer|Final answer)\s*:?\s*(.+?)(?:\n|$)/i);
    let value = (m?.[1] ?? answer).trim();
    value = value.replace(/[.,;]\s*$/, "").trim();
    value = value.replace(/^["'`]|["'`]$/g, "");
    if (isNumericalTarget(input, value)) value = sanitizeNumericValue(value) || value;
    return setTextInputValue(input, value);
  }
  function isNumericalTarget(input, rawValue) {
    if (input.type === "number") return true;
    if (input.classList.contains("numerical_question_input")) return true;
    const stripped = sanitizeNumericValue(rawValue, { forceStripCommas: true });
    return stripped !== "" && Number.isFinite(Number(stripped));
  }
  function sanitizeNumericValue(value, opts = {}) {
    const hasCurrencyOrPercent = /[$%]/.test(value);
    let cleaned = value.replace(/[$%]/g, "").replace(/\s+/g, "");
    if (hasCurrencyOrPercent || opts.forceStripCommas) cleaned = cleaned.replace(/,/g, "");
    return cleaned;
  }
  function setTextInputValue(input, value) {
    if (input.disabled || input.readOnly) {
      input.classList.add("statshelpr-suggested");
      return 1;
    }
    const proto = Object.getPrototypeOf(input);
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(input, value);
    else input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.classList.add("statshelpr-suggested");
    return 1;
  }
  function collectAnswerChoices(question) {
    const inputs = [...question.querySelectorAll(CHOICE_INPUT_SELECTOR)];
    const choices = [];
    const seenRows = /* @__PURE__ */ new Set();
    inputs.forEach((input, index) => {
      const row = getChoiceRow(input);
      if (row && seenRows.has(row)) return;
      if (row) seenRows.add(row);
      let text = normalizeText2(getChoiceText(input));
      if (!text) {
        if (!choiceHasImage(input)) return;
        text = `(image ${index + 1})`;
      }
      choices.push({
        input,
        label: choiceLabel(index),
        text,
        kind: input.type === "checkbox" ? "checkbox" : "radio"
      });
    });
    if (choices.length > 0) return choices;
    const selects = answerSelects(question);
    if (selects.length >= 2) return [];
    if (selects.length === 1) {
      const sel = selects[0];
      let idx = 0;
      for (const opt of [...sel.querySelectorAll("option")]) {
        const text = dedupeDoubled(opt.textContent ?? "");
        if (!text || /^\[?\s*(select|choose)\s*\]?\s*\.{0,3}$/i.test(text)) continue;
        choices.push({
          input: sel,
          label: choiceLabel(idx),
          text,
          kind: "dropdown-option",
          optionValue: opt.value,
          optionIndex: [...sel.options].indexOf(opt)
        });
        idx += 1;
      }
      if (choices.length > 0) return choices;
    }
    const allTextInputs = [...question.querySelectorAll(TEXT_INPUT_SELECTOR)];
    const enabledTextInputs = allTextInputs.filter((i) => !i.disabled && !i.readOnly);
    const soleTextInput = enabledTextInputs.length === 1 ? enabledTextInputs[0] : enabledTextInputs.length === 0 && allTextInputs.length === 1 ? allTextInputs[0] : void 0;
    if (soleTextInput) {
      choices.push({
        input: soleTextInput,
        label: "A",
        text: soleTextInput.placeholder || "(fill in your answer)",
        kind: "text-fill"
      });
    }
    return choices;
  }
  function choiceTypeForApi(c) {
    switch (c.kind) {
      case "checkbox":
        return "checkbox";
      case "dropdown-option":
        return "dropdown";
      case "text-fill":
        return "text";
      default:
        return "radio";
    }
  }
  function isAnswerSelect(sel) {
    const name = sel.name || "";
    if (/^answer_for_/i.test(name)) return true;
    if (sel.closest(".answers, .answer, .question_text, [data-testid*='question']")) return true;
    if (sel.classList.contains("question_input")) return true;
    return false;
  }
  function answerSelects(question) {
    return [...question.querySelectorAll("select")].filter(isAnswerSelect);
  }
  function collectBlanks(question) {
    const selects = answerSelects(question);
    if (selects.length >= 2) {
      return selects.map((sel, i) => {
        const options = [...sel.options].map((o, index) => ({ value: o.value, text: dedupeDoubled(o.textContent ?? ""), index })).filter((o) => o.text && !isPlaceholderOption(o.text));
        return { kind: "select", key: `blank${i + 1}`, label: blankLabel(sel, question), options, select: sel };
      });
    }
    return collectTextBlanks(question);
  }
  function collectTextBlanks(question) {
    if (question.querySelector(CHOICE_INPUT_SELECTOR)) return [];
    const inputs = [...question.querySelectorAll(TEXT_INPUT_SELECTOR)];
    const enabledCount = inputs.filter((i) => !i.disabled && !i.readOnly).length;
    if (enabledCount < 2) return [];
    const used = /* @__PURE__ */ new Set();
    return inputs.map((input, i) => ({
      kind: "input",
      key: inputBlankKey(input, i, used),
      label: blankLabel(input, question),
      options: [],
      input
    }));
  }
  function inputBlankKey(input, index, used) {
    for (const raw of [input.name, input.id]) {
      if (!raw) continue;
      const m = raw.match(/_([A-Za-z0-9]+)$/);
      const key = (m?.[1] ?? raw).trim();
      if (key && !used.has(key)) {
        used.add(key);
        return key;
      }
    }
    const fallback = `blank${index + 1}`;
    used.add(fallback);
    return fallback;
  }
  function blankLabel(el, question) {
    if (el.id) {
      const lab = question.querySelector(`label[for="${cssEscape(el.id)}"]`);
      const t = lab ? cleanText(lab) : "";
      if (t) return t;
    }
    const left = el.closest(".answer")?.querySelector(".answer_match_left");
    if (left) {
      const t = cleanText(left);
      if (t) return t;
    }
    const block = el.closest("li, p, td, .answer");
    if (block) {
      const clone = block.cloneNode(true);
      clone.querySelectorAll("select, input, script, style, .screenreader-only").forEach((n) => n.remove());
      const t = normalizeText2(clone.textContent ?? "");
      if (t) return t.slice(0, 200);
    }
    const aria = normalizeText2(el.getAttribute("aria-label") ?? "");
    return /multiple dropdowns/i.test(aria) ? "" : aria;
  }
  function isPlaceholderOption(text) {
    return !text || /^\[?\s*(select|choose)\s*\]?\s*\.{0,3}$/i.test(text);
  }
  function writeBlanks(question, answers) {
    const blanks = collectBlanks(question);
    let count = 0;
    answers.forEach((a, i) => {
      const blank = blanks.find((b) => b.key === a.key) ?? blanks[i];
      if (!blank || !a.answer) return;
      if (blank.kind === "input") {
        count += setTextInputValue(blank.input, a.answer);
        return;
      }
      const opt = matchBlankOption(a.answer, blank.options);
      if (opt) {
        count += setSelectValue(blank.select, opt.value, opt.index);
      } else {
        blank.select.classList.add("statshelpr-suggested");
        count += 1;
      }
    });
    return count;
  }
  function matchBlankOption(answer, options) {
    const a = normalizeText2(answer).toLowerCase();
    if (!a) return null;
    for (const o of options) if (o.text.toLowerCase() === a) return o;
    let best = null;
    let bestTier = -1;
    for (const o of options) {
      const ol = o.text.toLowerCase();
      if (!ol) continue;
      let tier = -1;
      if (a.includes(ol)) tier = isWordBoundaryMatch(a, ol) ? 1 : 0;
      else if (ol.length >= 3 && ol.includes(a)) tier = isWordBoundaryMatch(ol, a) ? 1 : 0;
      if (tier < 0) continue;
      if (tier > bestTier || tier === bestTier && o.text.length > (best?.text.length ?? 0)) {
        best = o;
        bestTier = tier;
      }
    }
    return best;
  }
  function isWordBoundaryMatch(haystack, needle) {
    if (!needle) return false;
    return new RegExp(`(?:^|[^a-z0-9])${escapeRegExp(needle)}(?:$|[^a-z0-9])`).test(haystack);
  }
  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function findSelectedChoices(answer, choices, allowMultiple) {
    const byLabel = new Map(choices.map((c) => [c.label.toUpperCase(), c]));
    const selected = /* @__PURE__ */ new Map();
    const answerLine = answer.match(/^\s*Answer\s*:?\s*(.+)$/im)?.[1] ?? answer.match(/correct(?:\s+interpretation)?(?:\(s\))?\s*:?\s*(.+)$/im)?.[1] ?? answer;
    for (const m of answerLine.matchAll(/\b([A-Z])\b/g)) {
      const letter = m[1];
      if (!letter) continue;
      const c = byLabel.get(letter.toUpperCase());
      if (c) {
        selected.set(c.input, c);
        if (!allowMultiple) return [c];
      }
    }
    const answerLower = answer.toLowerCase();
    for (const c of choices) {
      const choiceLower = c.text.toLowerCase();
      if (choiceLower.length >= 12 && answerLower.includes(choiceLower)) {
        selected.set(c.input, c);
      }
    }
    return [...selected.values()];
  }
  function getChoiceText(input) {
    if (input.id) {
      const label = document.querySelector(`label[for="${cssEscape(input.id)}"]`);
      if (label) return dedupeDoubled(textWithImageAlts(label));
    }
    const row = getChoiceRow(input);
    if (row) {
      const at = row.querySelector(".answer_text, .answer_html");
      const atText = at ? textWithImageAlts(at) : "";
      if (atText.trim()) return dedupeDoubled(atText);
      return dedupeDoubled(textWithImageAlts(row));
    }
    return "";
  }
  function choiceHasImage(input) {
    if (input.id) {
      const label = document.querySelector(`label[for="${cssEscape(input.id)}"]`);
      if (label?.querySelector("img")) return true;
    }
    const row = getChoiceRow(input);
    return Boolean(row?.querySelector("img"));
  }
  function getChoiceRow(input) {
    return input.closest(".answer") ?? input.closest(".answer_row") ?? input.closest("label") ?? input.parentElement;
  }
  function selectChoice(input) {
    const row = getChoiceRow(input);
    if (input.disabled) {
      row?.classList.add("statshelpr-suggested");
      return row ? 1 : 0;
    }
    if (!input.checked) input.click();
    if (!input.checked) {
      const proto = Object.getPrototypeOf(input);
      const setter = Object.getOwnPropertyDescriptor(proto, "checked")?.set;
      setter?.call(input, true);
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    }
    row?.classList.add("statshelpr-suggested");
    return 1;
  }
  function choiceLabel(index) {
    return String.fromCharCode(65 + index);
  }
  function normalizeText2(text) {
    return text.replace(/\s+/g, " ").trim();
  }
  function cleanText(el) {
    const clone = el.cloneNode(true);
    clone.querySelectorAll("script, style, .screenreader-only").forEach((n) => n.remove());
    replaceImagesWithAltText(clone);
    return normalizeText2(clone.textContent ?? "");
  }
  function textWithImageAlts(el) {
    const clone = el.cloneNode(true);
    replaceImagesWithAltText(clone);
    return clone.textContent ?? "";
  }
  function replaceImagesWithAltText(root) {
    root.querySelectorAll("img").forEach((img) => {
      const alt = img.getAttribute("alt") ?? "";
      img.replaceWith(document.createTextNode(alt ? ` ${alt} ` : ""));
    });
  }
  function cssEscape(s) {
    if (typeof CSS !== "undefined" && CSS.escape) return CSS.escape(s);
    return s.replace(/[^a-zA-Z0-9_-]/g, (c) => `\\${c}`);
  }
  function findStem(question) {
    for (const sel of SELECTORS_STEM) {
      const el = question.querySelector(sel);
      if (el && (el.innerText || el.textContent)?.trim()) return el;
    }
    return null;
  }
  async function collectImages(root) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const img of [...root.querySelectorAll("img")]) {
      const src = img.currentSrc || img.src || img.getAttribute("data-src") || img.getAttribute("data-original") || "";
      if (!src) continue;
      if (src.startsWith("data:") && src.length < 200) continue;
      if (/avatar|spinner|loading|icon-/.test(src)) continue;
      if (seen.has(src)) continue;
      seen.add(src);
      try {
        const block = await urlToImageBlock(src);
        if (block) out.push(block);
      } catch {
      }
    }
    for (const c of [...root.querySelectorAll("canvas")]) {
      try {
        const dataUrl = c.toDataURL("image/png");
        const data = dataUrl.split(",")[1];
        if (!data) continue;
        const key = `canvas:${data.length}`;
        if (seen.has(key)) continue;
        seen.add(key);
        out.push({ data, mediaType: "image/png" });
      } catch {
      }
    }
    return out;
  }
  async function urlToImageBlock(url) {
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok) return null;
    const blob = await res.blob();
    const t = blob.type.toLowerCase();
    let mediaType = null;
    if (t === "image/png") mediaType = "image/png";
    else if (t === "image/jpeg" || t === "image/jpg") mediaType = "image/jpeg";
    else if (t === "image/webp") mediaType = "image/webp";
    if (!mediaType) return null;
    const data = await new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => {
        const result = r.result;
        if (typeof result !== "string") return reject(new Error("read failed"));
        const idx = result.indexOf(",");
        resolve(idx >= 0 ? result.slice(idx + 1) : result);
      };
      r.onerror = () => reject(r.error);
      r.readAsDataURL(blob);
    });
    return { data, mediaType };
  }

  // src/telemetry.ts
  function deriveQuestionType(scraped) {
    const { choices, blanks } = scraped;
    if (blanks.length >= 2) {
      if (blanks.every((b) => b.kind === "input")) return "fill_in_multiple_blanks";
      const looksLikeMatching = blanks.some(
        (b) => b.kind === "select" && Boolean(b.select.closest(".answer")?.querySelector(".answer_match_left"))
      );
      return looksLikeMatching ? "matching" : "multiple_dropdowns";
    }
    if (choices.some((c) => c.kind === "checkbox")) return "multiple_answers";
    if (choices.some((c) => c.kind === "dropdown-option")) return "dropdown";
    if (choices.some((c) => c.kind === "text-fill")) return "numerical";
    const radios = choices.filter((c) => c.kind === "radio");
    if (radios.length === 2 && radios.every((c) => /^(true|false)$/i.test(c.text.trim()))) {
      return "true_false";
    }
    if (radios.length > 0) return "multiple_choice";
    return "unknown";
  }
  function deriveOutcome(writeCount, threw) {
    if (threw) return "error";
    return writeCount > 0 ? "written" : "nowrite";
  }
  function buildTelemetryBody(params) {
    return {
      mode: params.mode,
      questionType: params.questionType,
      confidence: params.confidence,
      outcome: params.outcome,
      writeCount: params.writeCount,
      clientLatencyMs: params.clientLatencyMs
    };
  }

  // src/r-packages.ts
  var RPKG_STORAGE_KEY = "statshelpr.rPackages";
  var DEFAULT_R_PACKAGES = [
    "tidyverse",
    "mosaic",
    "moderndive"
  ];
  var MAX_R_PACKAGES = 40;
  function isValidPackageName(name) {
    return /^[A-Za-z][A-Za-z0-9.]*$/.test(name) && name.length <= 64;
  }
  async function loadRPackages() {
    try {
      const r = await chrome.storage.sync.get(RPKG_STORAGE_KEY);
      const stored = r[RPKG_STORAGE_KEY];
      if (Array.isArray(stored)) {
        return { list: stored.filter(isValidPackageName).slice(0, MAX_R_PACKAGES), customized: true };
      }
      return { list: [...DEFAULT_R_PACKAGES], customized: false };
    } catch {
      return { list: [...DEFAULT_R_PACKAGES], customized: false };
    }
  }

  // src/content.ts
  var SELECTORS_QUESTION = [
    ".question_holder",
    ".display_question",
    "[data-testid='question-container']",
    "[data-testid='quiz-question']",
    ".question-container",
    ".QuestionItem",
    ".item-body"
  ];
  var SELECTORS_HEADER = [
    ".question_name",
    // Classic Quizzes — the "Question 1" span
    ".header .question_name",
    ".question .header",
    "[data-testid='question-number']",
    // New Quizzes (guess)
    "[data-testid='question-header']"
  ];
  var QUESTION_SELECTOR = SELECTORS_QUESTION.join(",");
  var STORAGE_KEY_FILES = "statshelpr.files";
  var FILE_TTL_MS = 7 * 24 * 60 * 60 * 1e3;
  var STORAGE_KEY_SOLVE_STATS = "statshelpr.solveStats";
  var FREE_DAILY_LIMIT = 5;
  var SOLVE_WINDOW_MS = 24 * 60 * 60 * 1e3;
  var dataFiles = [];
  function boot() {
    void loadFiles().then(() => scanAndInject());
    void applyButtonOpacityFromStorage();
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[STORAGE_KEY_FILES]) {
        void loadFiles();
      }
      if (area === "sync" && changes["buttonOpacity"]) {
        const next = changes["buttonOpacity"].newValue;
        if (typeof next === "number") applyButtonOpacity(next);
      }
    });
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === "sh-preview-opacity" && typeof msg.value === "number") {
        applyButtonOpacity(msg.value);
      }
    });
    const observer = new MutationObserver(() => scanAndInject());
    observer.observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
  var pendingScan = false;
  function scanAndInject() {
    if (pendingScan) return;
    pendingScan = true;
    setTimeout(() => {
      pendingScan = false;
      for (const sel of SELECTORS_QUESTION) {
        document.querySelectorAll(sel).forEach(injectButtonFor);
      }
    }, 100);
  }
  function injectButtonFor(question) {
    if (question.dataset["statshelprAttached"] === "1") return;
    if (hasQuestionAncestor(question)) return;
    if (!findStem(question)) return;
    const btn = mkEl("button", {
      className: "statshelpr-btn-tutor",
      type: "button",
      title: ""
    });
    btn.appendChild(mkEl("span", { className: "statshelpr-btn-text", text: "solve" }));
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      void onSolve(question, btn);
    });
    const anchor = findHeader(question);
    if (anchor) {
      anchor.appendChild(document.createTextNode(" "));
      anchor.appendChild(btn);
    } else {
      const wrap = mkEl("div", { className: "statshelpr-tutor-wrap" });
      wrap.appendChild(btn);
      question.insertBefore(wrap, question.firstChild);
    }
    question.dataset["statshelprAttached"] = "1";
  }
  function findHeader(question) {
    for (const sel of SELECTORS_HEADER) {
      const el = question.querySelector(sel);
      if (el) return el;
    }
    return null;
  }
  function hasQuestionAncestor(question) {
    const ancestor = question.parentElement?.closest(QUESTION_SELECTOR);
    return Boolean(ancestor && findStem(ancestor));
  }
  var SSE_IDLE_TIMEOUT_MS = 3e4;
  function armIdleAbort(ctrl, ms) {
    let timedOut = false;
    let timer;
    const poke = () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => {
        timedOut = true;
        ctrl.abort();
      }, ms);
    };
    poke();
    return {
      poke,
      clear: () => {
        if (timer) clearTimeout(timer);
      },
      get timedOut() {
        return timedOut;
      }
    };
  }
  async function onSolve(question, btn) {
    if (btn.disabled) return;
    const solveStartedAt = performance.now();
    setBtnState(btn, "loading");
    question.querySelectorAll(".statshelpr-suggested").forEach(
      (el) => el.classList.remove("statshelpr-suggested")
    );
    try {
      await loadFiles();
    } catch (e) {
      setBtnState(btn, "error", e.message);
      return;
    }
    let scraped;
    try {
      scraped = await scrapeQuestion(question);
    } catch (e) {
      setBtnState(btn, "error", e.message);
      return;
    }
    let cfg;
    let installId;
    try {
      cfg = await getConfig();
      installId = await getInstallId();
    } catch (e) {
      setBtnState(btn, "error", e.message);
      return;
    }
    const apiUrl = (cfg.apiUrl ?? "https://api.statshelpr.com").replace(/\/$/, "");
    const licenseKey = cfg.licenseKey ?? "";
    const headers = {
      "Content-Type": "application/json",
      "X-Install-Id": installId,
      ...licenseKey ? { Authorization: `Bearer ${licenseKey}` } : {}
    };
    const apiChoices = scraped.choices.map((c) => ({
      label: c.label,
      text: c.text,
      type: choiceTypeForApi(c)
    }));
    const apiBlanks = scraped.blanks.map((b) => ({
      key: b.key,
      label: b.label,
      options: b.options.map((o) => o.text)
    }));
    const apiDataFiles = dataFiles.map((f) => ({ filename: f.filename, content: f.content }));
    const { list: rPackages, customized: rPackagesCustomized } = await loadRPackages();
    const solveCtrl = new AbortController();
    const solveIdle = armIdleAbort(solveCtrl, SSE_IDLE_TIMEOUT_MS);
    let final;
    try {
      const solveRes = await fetch(`${apiUrl}/api/solve`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          questionText: scraped.text,
          choices: apiChoices,
          ...apiBlanks.length ? { blanks: apiBlanks } : {},
          images: scraped.images,
          dataFiles: apiDataFiles,
          ...rPackagesCustomized ? { packages: rPackages } : {}
        }),
        signal: solveCtrl.signal
      });
      if (!solveRes.ok) {
        const bodyText = await solveRes.text();
        if (solveRes.status === 402) {
          let resetAt;
          try {
            resetAt = JSON.parse(bodyText).resetAt;
          } catch {
          }
          void recordSolveLimitHit(resetAt);
        } else if (solveRes.status === 403) {
          let atLimit = false;
          try {
            atLimit = JSON.parse(bodyText).atLimit === true;
          } catch {
          }
          if (atLimit) void recordActivationBlocked();
        }
        throw new Error(extractErrorMsg(bodyText));
      }
      void recordSolveUse();
      void clearActivationBlocked();
      const solveResult = await consumeSseResult(solveRes, solveIdle.poke);
      if (solveResult.mode === "concept" || solveResult.mode === "calc") {
        final = solveResult;
      } else {
        throw new Error("Unexpected response from solve.");
      }
    } catch (e) {
      const message = solveIdle.timedOut ? `No response for ${SSE_IDLE_TIMEOUT_MS / 1e3}s \u2014 check your connection and try again.` : e.message;
      setBtnState(btn, "error", message);
      return;
    } finally {
      solveIdle.clear();
    }
    const cleaned = stripTags(final.answer);
    const telemetryBase = {
      apiUrl,
      installId,
      telemetryDisabled: cfg.telemetryDisabled === true,
      mode: final.mode,
      confidence: final.confidence,
      questionType: deriveQuestionType(scraped),
      startedAt: solveStartedAt
    };
    let writeCount;
    try {
      writeCount = final.blanks && final.blanks.length > 0 && scraped.blanks.length > 0 ? writeBlanks(question, final.blanks) : selectAnswerChoice(question, cleaned, final.selectedChoices ?? [], scraped.choices);
    } catch (e) {
      fireTelemetryBeacon({ ...telemetryBase, writeCount: 0, threw: true });
      throw e;
    }
    if (writeCount === 0) {
      setBtnState(btn, "nowrite", `Couldn't auto-select \u2014 answer: ${cleaned.slice(0, 200)}`);
    } else {
      setBtnState(btn, "default");
    }
    if (final.mode === "calc" && final.dataMissing) {
      showToast("Dataset not found \u2014 answered from reasoning. Upload the CSV for an exact result.");
    }
    fireTelemetryBeacon({ ...telemetryBase, writeCount, threw: false });
  }
  var activeToast = null;
  function showToast(message, ms = 5e3) {
    if (activeToast) {
      clearTimeout(activeToast.timer);
      activeToast.el.remove();
      activeToast = null;
    }
    const toast = mkEl("div", { className: "statshelpr-toast", text: message });
    const dismiss = () => {
      if (activeToast?.el !== toast) return;
      toast.classList.add("leaving");
      setTimeout(() => toast.remove(), 220);
      activeToast = null;
    };
    toast.addEventListener("click", dismiss);
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add("shown"));
    activeToast = { el: toast, timer: setTimeout(dismiss, ms) };
  }
  function fireTelemetryBeacon(args) {
    if (args.telemetryDisabled) return;
    const body = buildTelemetryBody({
      mode: args.mode,
      questionType: args.questionType,
      confidence: args.confidence,
      outcome: deriveOutcome(args.writeCount, args.threw),
      writeCount: args.writeCount,
      clientLatencyMs: Math.round(performance.now() - args.startedAt)
    });
    void fetch(`${args.apiUrl}/api/telemetry`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Install-Id": args.installId },
      body: JSON.stringify(body)
    }).catch(() => {
    });
  }
  function extractErrorMsg(body) {
    let msg = body.slice(0, 200);
    try {
      const parsed = JSON.parse(body);
      if (parsed.error) msg = parsed.error;
    } catch {
    }
    return msg;
  }
  function stripTags(s) {
    return s.replace(/^\s*\[(CONCEPT|RCODE|CALC)\]\s*\n?/i, "").trim();
  }
  async function recordSolveUse() {
    try {
      const r = await chrome.storage.local.get(STORAGE_KEY_SOLVE_STATS);
      const prev = r[STORAGE_KEY_SOLVE_STATS];
      const now = Date.now();
      const next = !prev || prev.resetAt < now ? { count: 1, resetAt: now + SOLVE_WINDOW_MS } : { count: prev.count + 1, resetAt: prev.resetAt };
      await chrome.storage.local.set({ [STORAGE_KEY_SOLVE_STATS]: next });
    } catch {
    }
  }
  async function recordSolveLimitHit(resetAt) {
    try {
      const next = {
        count: FREE_DAILY_LIMIT,
        resetAt: resetAt ?? Date.now() + SOLVE_WINDOW_MS
      };
      await chrome.storage.local.set({ [STORAGE_KEY_SOLVE_STATS]: next });
    } catch {
    }
  }
  async function recordActivationBlocked() {
    try {
      await chrome.storage.local.set({ activationBlocked: true });
    } catch {
    }
  }
  async function clearActivationBlocked() {
    try {
      const r = await chrome.storage.local.get("activationBlocked");
      if (r["activationBlocked"]) await chrome.storage.local.remove("activationBlocked");
    } catch {
    }
  }
  async function consumeSseResult(res, poke) {
    const reader = res.body?.getReader();
    if (!reader) throw new Error("Empty response stream.");
    const decoder = new TextDecoder();
    let buf = "";
    let result = null;
    let errorMsg = null;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      poke();
      buf += decoder.decode(value, { stream: true });
      const frames = buf.split("\n\n");
      buf = frames.pop() ?? "";
      for (const frame of frames) {
        const dataLine = frame.split("\n").find((l) => l.startsWith("data:"));
        if (!dataLine) continue;
        const jsonStr = dataLine.slice(5).trim();
        if (!jsonStr) continue;
        let evt;
        try {
          evt = JSON.parse(jsonStr);
        } catch {
          continue;
        }
        if (evt.type === "result") result = evt.result;
        else if (evt.type === "error") errorMsg = evt.message;
      }
    }
    if (errorMsg) throw new Error(errorMsg);
    if (!result) throw new Error("No result received from server.");
    return result;
  }
  function setBtnState(btn, state, msg) {
    btn.classList.remove("loading", "error", "nowrite");
    btn.removeAttribute("title");
    switch (state) {
      case "loading":
        btn.classList.add("loading");
        btn.disabled = true;
        clear(btn);
        btn.appendChild(mkEl("span", { className: "statshelpr-spinner" }));
        return;
      case "error":
        btn.classList.add("error");
        btn.disabled = false;
        btn.textContent = "!";
        btn.setAttribute("title", msg ?? "");
        return;
      case "nowrite":
        btn.classList.add("nowrite");
        btn.disabled = false;
        btn.textContent = "?";
        btn.setAttribute("title", msg ?? "");
        return;
      default:
        btn.disabled = false;
        clear(btn);
        btn.appendChild(mkEl("span", { className: "statshelpr-btn-text", text: "solve" }));
        btn.setAttribute("title", "");
    }
  }
  async function loadFiles() {
    const r = await chrome.storage.local.get(STORAGE_KEY_FILES);
    const stored = r[STORAGE_KEY_FILES] ?? [];
    const now = Date.now();
    dataFiles = stored.filter((f) => now - f.addedAt < FILE_TTL_MS);
  }
  async function applyButtonOpacityFromStorage() {
    const r = await chrome.storage.sync.get(["buttonOpacity"]);
    applyButtonOpacity(typeof r.buttonOpacity === "number" ? r.buttonOpacity : 1);
  }
  var DIM_GAMMA = 2.2;
  function applyButtonOpacity(dial) {
    const clamped = Math.min(1, Math.max(0, dial));
    const opacity = Math.pow(clamped, DIM_GAMMA).toFixed(4);
    document.documentElement.style.setProperty("--sh-text-opacity", opacity);
    document.documentElement.style.setProperty("--sh-outline-opacity", opacity);
  }
  async function getConfig() {
    const r = await chrome.storage.sync.get(["apiUrl", "licenseKey", "telemetryDisabled"]);
    return r;
  }
  function mkEl(tag, opts = {}, children = []) {
    const node = document.createElement(tag);
    if (opts.className) node.className = opts.className;
    if (opts.id) node.id = opts.id;
    if (opts.title) node.title = opts.title;
    if (opts.style) node.setAttribute("style", opts.style);
    if (opts.type && tag === "button")
      node.type = opts.type;
    if (opts.text !== void 0) node.textContent = opts.text;
    for (const c of children) {
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return node;
  }
  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
  }
})();
