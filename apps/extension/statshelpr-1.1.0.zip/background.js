"use strict";
(() => {
  // src/install-id.ts
  var STORAGE_KEY_INSTALL_ID = "installId";
  async function getInstallId() {
    const r = await chrome.storage.sync.get(STORAGE_KEY_INSTALL_ID);
    const existing = r[STORAGE_KEY_INSTALL_ID];
    if (existing) return existing;
    const id = crypto.randomUUID();
    await chrome.storage.sync.set({ [STORAGE_KEY_INSTALL_ID]: id });
    return id;
  }

  // src/claim-license.ts
  var DEFAULT_API_URL = "https://api.statshelpr.com";
  var CLAIM_ALARM = "statshelpr-claim-license";
  var STORAGE_KEY_CLAIM_STARTED = "claimStartedAt";
  var CLAIM_WINDOW_MS = 45 * 6e4;
  async function stopClaiming() {
    await chrome.storage.local.remove(STORAGE_KEY_CLAIM_STARTED);
    await chrome.alarms.clear(CLAIM_ALARM);
  }
  async function tryClaimLicense() {
    const r = await chrome.storage.local.get(STORAGE_KEY_CLAIM_STARTED);
    const startedAt = r[STORAGE_KEY_CLAIM_STARTED];
    if (!startedAt) return "none";
    if (Date.now() - startedAt > CLAIM_WINDOW_MS) {
      await stopClaiming();
      return "none";
    }
    const cfg = await chrome.storage.sync.get("apiUrl");
    const apiBase = (cfg["apiUrl"] ?? DEFAULT_API_URL).replace(/\/$/, "");
    const installId = await getInstallId();
    let data;
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 6e3);
      const res = await fetch(`${apiBase}/api/claim-license`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ installId }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      data = await res.json();
    } catch {
      return "pending";
    }
    if (!data.ok || !data.licenseKey) return "pending";
    await chrome.storage.sync.set({ licenseKey: data.licenseKey });
    await chrome.storage.local.set({ activationBlocked: false });
    await stopClaiming();
    return "claimed";
  }

  // src/background.ts
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === CLAIM_ALARM) void tryClaimLicense();
  });
  chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") {
      void chrome.tabs.create({
        url: chrome.runtime.getURL("welcome.html")
      });
    }
  });
  chrome.runtime.onMessage.addListener(
    (msg, _sender, sendResponse) => {
      if (msg.type === "openWelcome") {
        void chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
        sendResponse({ ok: true });
        return false;
      }
      if (msg.type === "solve") {
        handleSolve(msg.payload).then((result) => sendResponse({ ok: true, result })).catch((e) => sendResponse({ ok: false, error: e.message }));
        return true;
      }
      return false;
    }
  );
  async function handleSolve(payload) {
    const cfg = await chrome.storage.sync.get(["apiUrl", "licenseKey"]);
    const apiUrl = cfg["apiUrl"] ?? "https://api.statshelpr.com";
    const licenseKey = cfg["licenseKey"] ?? "";
    const installId = await getInstallId();
    const res = await fetch(`${apiUrl}/api/solve`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Install-Id": installId,
        ...licenseKey ? { Authorization: `Bearer ${licenseKey}` } : {}
      },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const body = await res.text();
      throw new Error(`API ${res.status}: ${body.slice(0, 300)}`);
    }
    return await res.json();
  }
})();
