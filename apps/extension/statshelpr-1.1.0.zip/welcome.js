"use strict";
(() => {
  // src/welcome.ts
  var STORAGE_KEY = "statshelpr.welcomeShown";
  var steps = document.querySelectorAll(".step");
  function goTo(n) {
    steps.forEach((step) => {
      const id = Number(step.dataset["step"]);
      step.classList.toggle("hidden", id !== n);
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  document.querySelectorAll("[data-go]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const n = Number(btn.dataset["go"]);
      if (n) goTo(n);
    });
  });
  document.getElementById("skip-btn")?.addEventListener("click", finish);
  document.getElementById("finish-btn")?.addEventListener("click", finish);
  var DIM_GAMMA = 2.2;
  var discreetSlider = document.getElementById("discreet-slider");
  var discreetBtn = document.getElementById("discreet-demo-btn");
  var discreetText = document.getElementById("discreet-demo-text");
  var discreetValue = document.getElementById("discreet-slider-value");
  if (discreetSlider && discreetBtn && discreetText && discreetValue) {
    const applyOpacity = () => {
      const dial = Math.min(1, Math.max(0, Number(discreetSlider.value) / 100));
      const op = Math.pow(dial, DIM_GAMMA).toFixed(4);
      discreetText.style.opacity = op;
      discreetBtn.style.borderColor = `rgba(39, 66, 200, ${op})`;
      discreetBtn.style.backgroundColor = `rgba(255, 255, 255, ${op})`;
      discreetValue.textContent = `${discreetSlider.value}%`;
    };
    discreetSlider.addEventListener("input", applyOpacity);
    applyOpacity();
  }
  function finish() {
    void chrome.storage.sync.set({ [STORAGE_KEY]: true }).then(() => {
      window.close();
    });
  }
  var observer = new MutationObserver(() => {
    const lastStep = document.querySelector('[data-step="4"]');
    if (lastStep && !lastStep.classList.contains("hidden")) {
      void chrome.storage.sync.set({ [STORAGE_KEY]: true });
    }
  });
  observer.observe(document.body, {
    attributes: true,
    attributeFilter: ["class"],
    subtree: true
  });
})();
